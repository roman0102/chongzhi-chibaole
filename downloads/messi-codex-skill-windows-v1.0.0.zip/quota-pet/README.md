# Messi Codex-connected desktop pet

[中文](guides/zh-CN.md) · [English](guides/en.md) · [Español](guides/es.md) · [日本語](guides/ja.md) · [한국어](guides/ko.md)

# 梅西毛绒公仔 · 重置吃饱了

基于用户上传的阿根廷 10 号毛绒公仔图片制作。本地 Python/Tk 桌宠，包含八组动作；所有动作穿同一套阿根廷球衣。美术为内置 imagegen 对上传公仔的改编，提示词在 assets/messi/generation-prompts.txt。

## 启动

将 quota-pet 文件夹交给 Codex，说明：

> 使用这里的 SKILL.md，启动 assets/messi/skin.json 这只公仔，读取真实额度与工作状态，并创建公仔图标的桌面快捷方式。

需要 Python 3.10+、Tk 和 Pillow。已有这些依赖时，也可以在 quota-pet 目录运行：

```text
python scripts/quota_pet.py --skin assets/messi/skin.json --background
python scripts/create_shortcut.py --skin assets/messi/skin.json
```

## 动作

| 触发条件 | 公仔表现 |
| --- | --- |
| 静止、额度 100% | 亲吻金杯 |
| 静止、额度 80% 至不足 100% | 突然站直、双手捂耳，保持严肃，不眨眼 |
| 额度 0% | 瞪眼、撇嘴、转头，停止漫游；同时显示 ¿Qué mirás, bobo? |
| 工作或空闲漫游 | 左右带球奔跑 |
| Codex 等待回复或批准 | 挥手说话，气泡显示 ¿Qué mirás, bobo? |
| 授权检查发现新邮件 | 严肃、全程睁眼，像晒球衣一样举起放大的信封并保持展示 |

实时模式下，工作等待与错误状态优先于邮件，邮件优先于额度动作。未知额度不当作 0%。点击/右键打开菜单，能试玩各档额度与动作；额度试玩优先展示所选额度造型并停止移动，不会再被真实工作覆盖。试玩会标明模拟状态，不更改真实额度和工作状态。通过“刷新真实额度”恢复实时模式。鼠标悬停显示状态卡，移开隐藏；可拖动，Esc 退出。

Gmail 默认关闭，尚未为此公仔启用真实邮箱检查。动作试玩只显示信封姿势；启用流程和所用 Codex 额度说明在 references/gmail.md。

这是一份本地试玩包，不是 Codex 内置宠物，也不自动安装开机启动。素材未声明可商用授权。
